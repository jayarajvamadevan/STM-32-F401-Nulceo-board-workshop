#include "mbed.h"
#include "PCF8591.h"

Serial pc(USBTX, USBRX);
I2C i2c_bus(P0_29, P0_28); // sda, scl
PCF8591 adc_dac(&i2c_bus,PCF8591_SA0);

int main() {
    
    uint8_t analog = 0;
    while (1) {
        
        adc_dac.write(analog);        
        pc.printf("write analog: %d \r\n",analog);        
        wait(1);
                
        analog = analog + 25;
        if(analog>255)
            analog = 0; 
    }
}
