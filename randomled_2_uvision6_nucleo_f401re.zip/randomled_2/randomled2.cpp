#include "mbed.h" 
BusOut LEDS(PC_0,PC_1,PC_2,PC_3,PC_4,PC_5,PC_6,PC_7); 
int main() 
{ 
int Number,Tim; 
float Del; 
while(true) 
{ 
Number = rand() % 256; // Random number 0-255
 Tim = rand() % 11; // Random number 0 - 10
  Del = Tim *0.03; // Random delay 0-300ms 
  LEDS = Number; // Turn ON LEDs 
  wait(Del); // Random delay 
  } 
  }