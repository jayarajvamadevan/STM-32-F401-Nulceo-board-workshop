#include "mbed.h"
DigitalOut LED(PC_10); // External LED at PC_10
#define ON 1 // ON = 1
#define OFF 0 // OFF = 0
#define ONTime 0.5 // ONTime = 0.5s
#define OFFTime 0.5 // OFFTime = 2.0s
int main()
{
while(true) // DO FOREVER
{
LED = ON; // LED ON
wait(ONTime); // Wait ONTime seconds
LED = OFF; // LED OFF
wait(OFFTime); // Wait OFFTime seconds
}
}