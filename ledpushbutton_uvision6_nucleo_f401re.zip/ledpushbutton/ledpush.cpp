#include "mbed.h" 
DigitalOut led(LED1); // LED1 isoutput 
DigitalIn button(BUTTON1); // BUTTON1 is input
 int main()
  { 
  while(true) // DO forever 
  {
       if(button == 0) // If button is pressed 
       { 
       for(int k = 0; k < 3; k++) // Do 3 times 
       { 
       led = 1; // LED ON 
       wait(1.0); // Wait 1 second 
       led = 0; // LED OFF 
       wait(1.0); // Wait 1 second
       } 
       } 
       } 
       }