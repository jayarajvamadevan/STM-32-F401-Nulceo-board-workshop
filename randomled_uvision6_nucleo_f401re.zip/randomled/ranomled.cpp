#include "mbed.h" 
BusOut LEDS(PC_0,PC_1,PC_2,PC_3,PC_4,PC_5,PC_6,PC_7);
int main() 
{ 
int Number; 
while(1) // Do forever
 { 
 Number = rand() % 256; // GEnerate a random numner
  LEDS = Number; // Send the numebr to PORT C
   wait(0.25); // 250ms delay 
   } 
   }