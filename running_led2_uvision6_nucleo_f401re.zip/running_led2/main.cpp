#include "mbed.h" 
BusOut LEDS(PC_0,PC_1,PC_2,PC_3,PC_4,PC_5,PC_6,PC_7); 
int main()
 { 
 int k = 0; // First LED 
 while(1) // Endless loop
  {
       LEDS = 1 << k; // LED ON 
       wait(0.5); // Wait 0.5 second
        k++; // Increment LED count
         if(k == 8)k = 0; // Back to first LED
          }
           }