#include "mbed.h"
 BusOut LEDS(PC_0,PC_1,PC_2,PC_3,PC_4,PC_5,PC_6,PC_7); 
 int main()
  {
       int CNT = 0; // CNT = 0 
       while(true) // Endless loop 
       {
            LEDS = CNT; // Turn ON LED 
            wait(1.0); // Wait 1 second 
            CNT++; // Increment CNT 
            if(CNT > 255)CNT = 0; // CNT back to 0 
            } 
            }