#include "mbed.h" 
Serial MyPC(USBTX, USBRX); 
AnalogIn pot(PA_0); 
DigitalOut LED(PC_10); 
#define ON 1 
#define OFF 0 
int main() 
{
     float Dig;
      while(true) // Do forever
       {
            Dig = pot.read(); // In mV 
            
            LED = ON; // LED ON 
            wait(Dig); // Delay 
            LED = OFF; // LED OFF 
            wait(Dig); // Delay 
          MyPC.printf("\n\r Pot value= %5.2f", Dig);
            } 
            }