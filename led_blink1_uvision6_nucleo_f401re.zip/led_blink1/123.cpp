#include "mbed.h"

DigitalOut myled(LED1);

int main() {
    // Led blinking - The led is switched on and off
    while(true) {
        myled = 1; // The LED is ON
        wait(0.2); // Stop the program counter here and wait for 200 ms. In the meanwhile the led is on
        myled = 0; // Switch-off the LED
        wait(2.0); // Stop the program counter here and wait for 1 ms. In the meanwhile the led is off
    }
}

