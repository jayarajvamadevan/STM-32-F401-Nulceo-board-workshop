#include "mbed.h" 
DigitalOut LEDS[] = {(PC_0),(PC_1),(PC_2),(PC_3),(PC_4),(PC_5),(PC_6),(PC_7)};
int main() 
{ 
int k; 
while(true) 
{ 
for(k = 0; k <= 7; k++) // Do 8 times 
{ 
LEDS[k] = 1; //LED ON
 wait(0.1); // WAit 1 second 
 LEDS[k] = 0; // LED OFF
  wait(0.1); // WAit 1 second 
  } 
  } 
  }             
                                             