#include "mbed.h" 
Serial RASP(USBTX, USBRX); 
int main()
 { 
    RASP.printf("Testing the serial interface");
 }