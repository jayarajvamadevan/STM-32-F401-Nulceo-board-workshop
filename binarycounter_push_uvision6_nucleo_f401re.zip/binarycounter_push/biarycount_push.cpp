#include "mbed.h" 
BusOut LEDS(PC_0,PC_1,PC_2,PC_3,PC_4,PC_5,PC_6,PC_7); 
DigitalIn button(BUTTON1); 
int main() 
{ 
int Cnt = 0; // Cnt = 0 to start with
 LEDS = 0; // All LEDs OFF at beginning 
 while(1) // DO Forever
  { 
  if(button == 0) // If button is pressed 
  { 
  Cnt++; // Increment Cnt 
  LEDS = Cnt; // Display Cnt
   while(button == 0); // Wait until button released 
   } 
   } 
   }