#include "mbed.h" 
Serial MyPC(USBTX, USBRX); 
AnalogIn ain(PA_0);
 // Clear the screen 
 // 
 void clrscr()
  { 
  char clrscr[] = {0x1B, '[', '2' , 'J',0}; 
  MyPC.printf(clrscr); 
  }
  // 
  // Home the cursor
   // 
   void homescr()
    {
         char homescr[] = {0x1B, '[' , 'H' , 0}; 
         MyPC.printf(homescr);
          } 
          // 
          // Goto specified line and column 
          //
           void gotoscr(int line, int column)
            {
                 char scr[] = {0x1B, '[', 0x00, ';' ,0x00, 'H', 0}; 
                 scr[2] = line; 
                 scr[4] = column; 
                 MyPC.printf(scr); 
                 } 
                 int main() 
                 { 
                 double mV, T; 
                 clrscr(); // Clear the screen
                  homescr(); // Home teh cursor 
                  MyPC.printf("\n\rDIGITAL THERMOMETER"); // Heading 
                  MyPC.printf("\n\r===================");
                  while(1) // Do forever
                   { 
                   mV = 3300.0f * ain.read(); // Voltage in mV 
                   T = (-mV + 500.0f) / 10.0f; // Temperature in C
                    gotoscr('4', '0'); // Goto line 4 col 0
                     MyPC.printf("Temperature = ");
                      MyPC.printf("%5.2f", T); // Display voltage
                       wait(1.0); // Wait 1 second 
                       } 
                       }