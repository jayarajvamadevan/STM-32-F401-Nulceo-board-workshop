#include "mbed.h"
#include "TextLCD.h"
DigitalOut trig(PC_6); 
DigitalIn echo(PC_7);
Timer tmr ;
TextLCD lcd(PC_0,PC_1,PC_2,PC_3,PC_4,PC_5); 
//float H = 200.0;

float CalculateDistance(){   
    float EchoDuration , DistToHead;
    trig = 0; 
    wait_ms(80);
    trig = 1; 
    wait_us(10) ; 
    trig = 0;
    while (!echo);
    tmr.reset() ; 
    while (echo);
    EchoDuration = tmr.read_us(); 
    DistToHead = EchoDuration * 0.017f;
    return DistToHead ;
 }
int main(){
    float Distance;
    lcd.cls(); 
    tmr.start() ;
    while(true){  
        Distance = CalculateDistance(); 
        //Height = H - Distance ;
        lcd.locate(0, 0);
        lcd. printf("%6.2f cm ",Distance);
        wait(1.0);
        }
}