#include "mbed.h"
Serial MyPC(USBTX, USBRX); // // Clear the screen // 
void clrscr() 
{ 
char clrscr[] = {0x1B, '[', '2' , 'J',0};
 MyPC.printf(clrscr); } // // Home the cursor // 
 void homescr()
  { 
  char homescr[] = {0x1B, '[' , 'H' , 0};
  MyPC.printf(homescr); 
  }
   int main() 
   { 
   float radius, height, volume;
    float pi = 3.14159;
     clrscr(); // Clear the screen 
     homescr(); // Hoem teh cursor 
     MyPC.printf("Volume of a Cylinder"); // Display heading
     MyPC.printf("\n\r=================="); 
     MyPC.printf(""); 
     MyPC.printf("\n\rEnter the radius: "); 
     MyPC.scanf("%f", &radius); // Read the radius 
     MyPC.printf("\n\rEnter the height: "); 
     MyPC.scanf("%f", &height); // Read height
      volume = pi * radius * radius * height; // Calculate volume
       MyPC.printf("\n\rVolume = %f\n\r", volume); // Display volume 
       }