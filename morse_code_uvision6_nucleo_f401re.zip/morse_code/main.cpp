#include "mbed.h"
DigitalOut LED(LED1);
#define Dot 0.25 // Dot time
#define Dash 1.0 // Dash time
#define Gap 0.2 // Gap time
#define ON 1 // ON=1
#define OFF 0 // OFF=0
int main()
{
int i;
while(true) // Do Forever
{
for(i = 0; i < 5; i++) // Send 3 dots
{
LED = ON; // LED ON
wait(Dot); // Wait Dot time
LED = OFF; // LED OFF
wait(Gap); // Wait Gap time
}
wait(0.5); // 0.5 second delay
for(i = 0; i < 3; i++) // Send 3 dashes
{
LED = ON; // LED ON
wait(Dash); // Wait Dash time
LED = OFF; // LED OFF
wait(Gap); // Wait GAp time
}
wait(2.0); // Wait 2 second before repeating
}
}