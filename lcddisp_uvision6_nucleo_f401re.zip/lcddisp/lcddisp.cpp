#include "mbed.h"
#include "TextLCD.h"
TextLCD MyLCD(PC_0,PC_1,PC_2,PC_3,PC_4,PC_5);
int main()
{
    
         MyLCD.printf("HELLO KUTTU MONE");
   
    }