#include "mbed.h"
//
// Define the expansion board to development board UART connections
//
#define TX PA_9 // UART TX
#define RX PA_10 // UART RX
Serial esp(TX, RX); // UART TX,RX
//
// Configure all relays as outputs and de-activate all relays
//
DigitalOut Relay1(PC_0, 1);
DigitalOut Relay2(PC_1, 1);
//
// This function connects to the Wi-Fi
//
void ConnectToWiFi(){
    esp.printf("AT+RST\r\n");
    wait(2);
    esp.printf("AT+CWMODE=1\r\n");
    wait(3);
    esp.printf("AT+CWJAP=\"JioFi3_564B6F\",\"x6mbnn9sz7\"\r\n");
    wait(10);
    esp.printf("AT+CPIMUX=1\r\n");
    wait(3);
    esp.printf("AT+CIFSR\r\n");
    wait(3);
    esp.printf("AT+CIPSTART=\"UDP\",\"0.0.0.0\",0,5000,2\r\n");
    wait(3);
    }
int main(){
    char Buffer[80]; // Buffer to store data
    esp.baud(9600); // Set baud rate to 9600
    ConnectToWiFi(); // Connect to Wi-Fi
    while(1){
        for(int k = 0; k < 5; k++)Buffer[k] = 0;
        esp.scanf("%s",Buffer);
        if(strstr(Buffer, "ON1") > 0) Relay1 = 0;
        else if(strstr(Buffer,"ON2") > 0) Relay2 = 0;
        else if(strstr(Buffer, "OFF1") > 0)Relay1 = 1;
        else if(strstr(Buffer, "OFF2") > 0)Relay2 = 1;
            }
        }